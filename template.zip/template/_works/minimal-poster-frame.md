---
title: Minimal Poster Frame
category: Image
category_slug: f-image
type: image
image: assets/img/works/work7.jpg
---
