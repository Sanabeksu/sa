---
title: Coffee Cup In Hand
category: Video
category_slug: f-video
type: video
image: assets/img/works/work2.jpg
video: https://youtu.be/S4L8T2kFFck
---
