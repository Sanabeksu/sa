---
title: Canvas Tote Bag MockUp
category: Gallery
category_slug: f-gallery
type: gallery
image: assets/img/works/work1.jpg
gallery: assets/img/works/work1.jpg,assets/img/works/work2.jpg,assets/img/works/work3.jpg
---
